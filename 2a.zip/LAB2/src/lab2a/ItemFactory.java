package lab2a;

public abstract class ItemFactory {
    public abstract Item createWeapon();
    public abstract Item createPowerUp();
}