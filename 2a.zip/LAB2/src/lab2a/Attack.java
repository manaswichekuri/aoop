package lab2a;

public class Attack implements Item {
    @Override
    public void useItem() {
        System.out.println("Performing my Attack with my weapon.");
    }    
}
