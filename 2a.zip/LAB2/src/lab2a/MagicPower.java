package lab2a;

public class MagicPower implements Item {
    @Override
    public void useItem() {
        System.out.println("Using my 7Star Ultimate Explosion ATTACK!!..");
    }
}