package lab2a;

public interface Enemy {
    void performAttack();
}
