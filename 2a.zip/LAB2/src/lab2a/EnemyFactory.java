package lab2a;

public abstract class EnemyFactory {
    public abstract Enemy createEnemy();
}