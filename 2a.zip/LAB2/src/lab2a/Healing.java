package lab2a;

public class Healing implements Item {
    @Override
    public void useItem() {
        System.out.println("I am Healing Myself..");
    }
}