package lab2a;

public class ToughEnemy implements Enemy {
    @Override
    public void performAttack() {
        System.out.println("It is an Tough Enemy, Brace yourself and ATTACK!!!..");
    }
}