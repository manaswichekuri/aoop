package lab2a;

public class EasyEnemy implements Enemy {
    @Override
    public void performAttack() {
        System.out.println("It is an Easy Enemy..ATTACK!!..");
    }
}

