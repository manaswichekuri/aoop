package lab2a;

public interface Item {
    void useItem();
}